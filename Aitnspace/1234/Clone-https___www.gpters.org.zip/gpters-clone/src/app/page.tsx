import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import Link from "next/link";

export default function Home() {
  return (
    <div className="container mx-auto py-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <span className="inline-block w-4 h-4 rounded-sm bg-primary" />
          새로 올라온 포스트
        </h1>
      </div>

      <div className="grid gap-6">
        {/* Post Card 1 */}
        <Card className="overflow-hidden">
          <div className="p-6">
            <div className="flex items-start gap-4">
              <Avatar className="w-10 h-10">
                <AvatarImage src="https://ext.same-assets.com/1011996629/2373990262.jpeg" alt="Profile" />
                <AvatarFallback>U</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex justify-between">
                  <Link href="/research/post" className="font-medium hover:text-primary">
                    OpenAI의 Deep Research 기능 이용법
                  </Link>
                  <span className="text-xs text-gray-500">2025.04.07</span>
                </div>
                <p className="mt-2 text-sm text-gray-700 line-clamp-3">
                  1. OpenAI의 새로운 기능 Deep Research에 대해 알아보겠습니다. 이 기능으로 무엇을 할 수 있는지 살펴봅시다.
                  2. OpenAI에서 새롭게 선보인 OpenAI Deep Research (일명 OpenAI 딥서치)란 복잡하고 깊이 있는 자료 조사와 리서치 작업을 위한 도구로,
                  웹에서 다양한 출처의 정보를 찾아 분석하고 요약할 수 있는 고급 기능입니다.
                </p>
                <div className="mt-3">
                  <Link href="/search?query=15기 딥리서치&type=post" className="text-xs bg-gray-100 px-2 py-1 rounded-md text-gray-600 hover:bg-gray-200">
                    15기 딥리서치
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Post Card 2 */}
        <Card className="overflow-hidden">
          <div className="p-6">
            <div className="flex items-start gap-4">
              <Avatar className="w-10 h-10">
                <AvatarImage src="https://ext.same-assets.com/1011996629/3557882121.jpeg" alt="Profile" />
                <AvatarFallback>U</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex justify-between">
                  <Link href="/media/post" className="font-medium hover:text-primary">
                    일관성있는 비디오 만들기
                  </Link>
                  <span className="text-xs text-gray-500">2025.04.07</span>
                </div>
                <p className="mt-2 text-sm text-gray-700 line-clamp-3">
                  일관성 있는 영상을 만들어 봤으니 리뷰를 해볼게요!! 저번에 이미지는 성공했는데..... 영상은 '토끼씨'가 몇 초 만에 300번 변신합니다.
                  그래도 영상에 의미는 담아보려고 했어요!
                </p>
                <div className="mt-3">
                  <Link href="/search?query=15기 나만의콘텐츠&type=post" className="text-xs bg-gray-100 px-2 py-1 rounded-md text-gray-600 hover:bg-gray-200">
                    15기 나만의콘텐츠
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Post Card 3 */}
        <Card className="overflow-hidden">
          <div className="p-6">
            <div className="flex items-start gap-4">
              <Avatar className="w-10 h-10">
                <AvatarImage src="https://ext.same-assets.com/1011996629/192835412.jpeg" alt="Profile" />
                <AvatarFallback>U</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex justify-between">
                  <Link href="/dev/post" className="font-medium hover:text-primary">
                    잘 만들어진 크롬 익스텐션의 사이드패널이 궁금해요
                  </Link>
                  <span className="text-xs text-gray-500">2025.04.07</span>
                </div>
                <p className="mt-2 text-sm text-gray-700 line-clamp-3">
                  버전 1은 사이드패널에서 사이트가 열리지 않았습니다. SidePanel으로 바로가기를 넣었어요. 사이드패널에서 사이트가 열리지 않아서,
                  크롬 탭으로 넘기는 기능만 넣었습니다. 버전 3을 만들면서 여러가지 개선해 볼까요? 일단 한번 해보겠습니다.
                </p>
                <div className="mt-3">
                  <Link href="/search?query=15기 크롬익스텐션&type=post" className="text-xs bg-gray-100 px-2 py-1 rounded-md text-gray-600 hover:bg-gray-200">
                    15기 크롬익스텐션
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Banner */}
        <div className="flex justify-center my-4">
          <div className="bg-primary text-white py-3 px-4 rounded-lg flex items-center gap-2 shadow-md">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z" />
            </svg>
            <span>AI스터디 16기 신청구매하고 최대 할인혜택 받기</span>
          </div>
        </div>

        {/* More Posts */}
        <Card className="overflow-hidden">
          <div className="p-6">
            <div className="flex items-start gap-4">
              <Avatar className="w-10 h-10">
                <AvatarImage src="https://ext.same-assets.com/1011996629/1876634679.jpeg" alt="Profile" />
                <AvatarFallback>V</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex justify-between">
                  <Link href="/nocode/post" className="font-medium hover:text-primary">
                    Vibe 오버플로우 전시장같은 쇼핑몰 / 온라인 쇼룸 (3/3)
                  </Link>
                  <span className="text-xs text-gray-500">2025.04.07</span>
                </div>
                <p className="mt-2 text-sm text-gray-700 line-clamp-3">
                  시행착오 정리하자면 다음과 같습니다. 1. Bubble AI 활용해서 개발을 빠르게 시작했습니다. 그런데 이상한 탭이 생기고 이상한 작동을 했습니다.
                </p>
                <div className="mt-3">
                  <Link href="/search?query=15기 CTO&type=post" className="text-xs bg-gray-100 px-2 py-1 rounded-md text-gray-600 hover:bg-gray-200">
                    15기 CTO
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Right Sidebar Content */}
      <div className="mt-8">
        <div className="bg-white rounded-lg p-4 shadow-sm mb-6">
          <h3 className="text-lg font-semibold mb-3">📣 많이 읽은 게시글</h3>
          <div className="space-y-4">
            <div>
              <Link href="/nocode/post" className="text-sm hover:text-primary line-clamp-2">
                Claude와 Notion 5분 만에 연결 설 (이모카님 채권)
              </Link>
            </div>
            <div>
              <Link href="/nocode/post" className="text-sm hover:text-primary line-clamp-2">
                뚜둥! 좋은 말씀(MCP) 전하려 왔습니다. - MCP Korea
              </Link>
            </div>
            <div>
              <Link href="/nocode/post" className="text-sm hover:text-primary line-clamp-2">
                토끼 & 고양이의 파리 여행 - 캐릭터 일관성 애니메이션 만들기
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
